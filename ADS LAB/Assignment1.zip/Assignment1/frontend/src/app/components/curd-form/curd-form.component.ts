import { Component } from '@angular/core';

@Component({
  selector: 'app-curd-form',
  templateUrl: './curd-form.component.html',
  styleUrls: ['./curd-form.component.css']
})
export class CurdFormComponent {

}
