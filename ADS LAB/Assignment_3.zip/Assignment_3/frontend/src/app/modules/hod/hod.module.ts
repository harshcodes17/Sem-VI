import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HodRoutingModule } from './hod-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HodRoutingModule
  ]
})
export class HodModule { }
