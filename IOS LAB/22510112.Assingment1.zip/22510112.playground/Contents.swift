let pi = 3.14159
var radius = 5.0
var area = pi * radius * radius

var circum = 2 * pi * radius
print("Circumference of the circle is: ",circum)

let birthYear = 2003
let currentYear = 2025
var myAge = currentYear - birthYear
print("My age is: ",myAge)


var marks = 97
let outOfMarks = 100
//outOfMarks = 250

var score = 100
print("I have chose to declare score as the variable because it is a mutable quantity")

print("To track the current temperture and freezing point of water")
print("Current Temperature will be stored in a var and as we know freezing point of the water is 0 degree celsius it will be stored in a let")
var currentTemosperature: Double = 25
let freezingPointOfWater: Double = 0

var age: Int = 21
var height: Double = 178.4


var firstDecimal = 0.1
var secondDecimal = 0.2

var trueOrFalse: Bool = true
//firstDecimal = trueOrFalse
print("firstDecimal cannot have value stored in trueOrFalse because trueOrFalse is a boolean value and firstDecimal is a decimal")

var name = "Harsh"
//firstDecimal = name
print("name cannot have value stored in firstDecimal because name is a string and firstDecimal is a decimal")

var wholeNum = 10
//firstDecimal = wholeNum
print("wholeNum cannot have value stored in firstDecimal because wholeNum is a whole number and firstDecimal is a decimal")

var fname : String
//print(fname)

var distanceTraveled:Double = 0
distanceTraveled = 54.3
print("Distance traveled is: ",distanceTraveled)

var percentCompleted:Double = 0
percentCompleted = 34.67



