
var num1 = 10
var num2 = 20

print("basic arithematic operations")
print(num1 + num2)
print(num1 - num2)
print(num1 * num2)
print(num1 / num2)

print("Compound assignment operators")

num1+=num2;
num2-=num1;

print("Operator precedence:")

var X = 1, Y = 2, Z = 3
print(X+Y*Z)
print((X+Y)*Z)

print("converting int to double")

var t1 : Int = 10
var doubled_t1 = Double(t1)
doubled_t1*=1.5
print(doubled_t1)

print("converting double to int")

var t2 : Double = 10.5

var intt_t2 = Int(t2)
intt_t2*=2;
print(intt_t2)

print("Check whether a number is even or odd")

var num : Int = 10

if num % 2 == 0
{
    print("Even")
}
else
{
    print("Odd")
}

print("Grading system based on marks")

var marks : Int = 85

if(marks >= 90 && marks <= 100){
    print("Grade:A")
}
if(marks >= 70 && marks < 90){
    print("Grade:B")
}
if(marks >= 50 && marks < 70){
    print("Grade:C")
}
if(marks>=30 && marks<50){
    print("Grade:D")
}
else{
    print( "Grade:D")
}

print("Authenticating of the username and the password....")
var username = "harsh"
var passwrod = "hello"

var user = "harsh"
var pass = "moshi"

if(user==username){
    if(pass == passwrod){
        print("Authentication successful!")
    }
    else{
        print("Password doesn't match!")
    }
}
else{
    print("Enter correct username!")
}

print("Get the day from the number")
var day:Int = 5

switch day{
case 1:
    print("Monday")
case 2:
    print("Tuesday")
case 3:
    print("Wednesday")
case 4:
    print("Thursday")
case 5:
    print("Friday")
case 6:
    print("Saturday")
case 7:
    print("Sunday")
default:
    print("Invalid day")
}


print("Find the largest among the three numbers")
var n1=2,n2=9,n3=4

if(n1>n2){
    if(n1>n3){
        print("Largest among the three is n1")
    }
    else if(n2>n3){
        print("Largest among the three is n2")
    }
}
else{
    if(n2>n3){
        print("Largets among the three is n2")
    }
    else{
        print("Largest Among the three is n3")
    }
}

print("Checking if you are eligible to vote or not ....")

var age : Int = 19
var canVote:Bool = false

if(age>=18 && canVote==true){
    print("The person is eligible to vote")
}
else{
    print("The person is not eligible to vote")
}

print("Checking if you are eligible for a discount")

var isStudent : Bool = true
var isSenior : Bool = false

if(isStudent||isSenior){
    print("Eligible for the discount")
}
else{
    print("Not eligible for the discount")
}

print("Using the boolen data type")
let number = 1000
let isSmallNumber = number<10

let speedLimit = 72
let currSpeed = 80
let isSpeeding = currSpeed>speedLimit

print("Type of the isSmallerNumber and the isSpeeding is :",type(of: isSmallNumber)," and ",type(of: isSpeeding))

//print("Enter your age: ")÷
//let agee = readLine()
//let numage = Int(agee!)!
print("Checking your age group ...")
let numage = 29

switch numage{
    case 1...12:
        print("You are a Child")
    case 13...19:
        print("You are a Teenager")
    case 20...65:
        print("You are an Adult")
    default:
        print("You are a senior")
}

print("Checking if its a weekend day or not ...")
var dayy:String = "Monday"

switch dayy{
    case "Saturday","Sunday":
    print("It is a weekend day")
default:
    print("It is a weekday")
}







