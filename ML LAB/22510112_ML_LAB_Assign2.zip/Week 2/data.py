import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats


np.random.seed(20)

sample_no = 1000



